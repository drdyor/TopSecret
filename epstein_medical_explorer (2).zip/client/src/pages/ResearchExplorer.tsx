import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, FileText, BarChart3, BookOpen } from "lucide-react";
import { researchCategories, documentStats, keyResearchers } from "@/lib/researchData";

export default function ResearchExplorer() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCategories = researchCategories.filter(cat =>
    cat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur-sm">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-slate-900">
                Medical Research Explorer
              </h1>
              <p className="mt-2 text-lg text-slate-600">
                Analysis of health and longevity research interests in the Epstein files
              </p>
            </div>
            <BookOpen className="h-12 w-12 text-blue-600 opacity-20" />
          </div>
        </div>
      </header>

      <main className="container py-12">
        {/* Statistics Overview */}
        <div className="mb-12 grid grid-cols-1 gap-4 md:grid-cols-4">
          <Card className="border-slate-200 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Total Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-900">{documentStats.totalResults}</div>
              <p className="text-xs text-slate-500 mt-1">Extracted documents</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Queries Processed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-900">{documentStats.totalQueries}</div>
              <p className="text-xs text-slate-500 mt-1">Health & research terms</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Success Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{documentStats.successRate}%</div>
              <p className="text-xs text-slate-500 mt-1">Extraction accuracy</p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{researchCategories.length}</div>
              <p className="text-xs text-slate-500 mt-1">Research domains</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Tabs */}
        <Tabs defaultValue="categories" className="space-y-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <TabsList className="grid w-full md:w-auto grid-cols-3">
              <TabsTrigger value="categories">Categories</TabsTrigger>
              <TabsTrigger value="sources">Sources</TabsTrigger>
              <TabsTrigger value="researchers">Key Researchers</TabsTrigger>
            </TabsList>

            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Search categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-slate-200"
              />
            </div>
          </div>

          {/* Categories Tab */}
          <TabsContent value="categories" className="space-y-6">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredCategories.map((category) => (
                <Card
                  key={category.id}
                  className={`cursor-pointer border-slate-200 transition-all hover:shadow-lg ${
                    selectedCategory === category.id ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg">{category.name}</CardTitle>
                        <CardDescription className="mt-2 text-sm">
                          {category.description}
                        </CardDescription>
                      </div>
                      <div className={`h-12 w-12 rounded-lg bg-gradient-to-br ${category.color} opacity-20`} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-600">Results Found</span>
                      <Badge variant="secondary" className="text-lg font-bold">
                        {category.resultCount}
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-slate-600 uppercase">Key Topics</p>
                      <div className="flex flex-wrap gap-2">
                        {category.keyTopics.slice(0, 3).map((topic) => (
                          <Badge key={topic} variant="outline" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                        {category.keyTopics.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{category.keyTopics.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-slate-600 uppercase">Documents</p>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <FileText className="h-4 w-4" />
                        {category.documents.length} files
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      className="w-full mt-4"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedCategory(category.id);
                      }}
                    >
                      Explore
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Selected Category Details */}
            {selectedCategory && (
              <Card className="border-blue-200 bg-blue-50/50">
                <CardHeader>
                  <CardTitle className="text-xl">
                    {researchCategories.find(c => c.id === selectedCategory)?.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">All Key Topics</h4>
                    <div className="flex flex-wrap gap-2">
                      {researchCategories
                        .find(c => c.id === selectedCategory)
                        ?.keyTopics.map((topic) => (
                          <Badge key={topic} className="bg-blue-600">
                            {topic}
                          </Badge>
                        ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">Associated Documents</h4>
                    <div className="space-y-2">
                      {researchCategories
                        .find(c => c.id === selectedCategory)
                        ?.documents.map((doc) => (
                          <div key={doc} className="flex items-center gap-2 p-2 bg-white rounded border border-slate-200">
                            <FileText className="h-4 w-4 text-blue-600" />
                            <span className="text-sm font-mono text-slate-700">{doc}</span>
                          </div>
                        ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Sources Tab */}
          <TabsContent value="sources" className="space-y-6">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {Object.entries(documentStats.sources).map(([source, count]) => (
                <Card key={source} className="border-slate-200">
                  <CardHeader>
                    <CardTitle className="text-lg">{source}</CardTitle>
                    <CardDescription>Data source</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-4xl font-bold text-blue-600">{count}</div>
                    <p className="text-sm text-slate-600 mt-2">
                      {source === "Jmail" && "Email correspondence"}
                      {source === "JDrive" && "Document archive"}
                      {source === "Jwiki" && "Encyclopedia entries"}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle>Document Type Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(documentStats.documentTypes).map(([type, count]) => (
                    <div key={type} className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-700 capitalize">
                        {type.replace("_", " ")}
                      </span>
                      <div className="flex items-center gap-3">
                        <div className="w-32 bg-slate-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{
                              width: `${(count / 340) * 100}%`
                            }}
                          />
                        </div>
                        <span className="text-sm font-bold text-slate-900 w-12 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Researchers Tab */}
          <TabsContent value="researchers" className="space-y-6">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {keyResearchers.map((researcher) => (
                <Card key={researcher.name} className="border-slate-200">
                  <CardHeader>
                    <CardTitle className="text-lg">{researcher.name}</CardTitle>
                    <CardDescription>{researcher.affiliation}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600">
                        <span className="font-semibold">Focus:</span> {researcher.focus}
                      </p>
                      <Badge variant="outline" className="mt-2">
                        Frontier Research
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="border-slate-200 bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardHeader>
                <CardTitle>Research Implications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-slate-700">
                <p>
                  The Epstein files reveal sophisticated engagement with frontier aging research, experimental medical approaches, and integrated health philosophies spanning physical, cognitive, psychological, and consciousness dimensions.
                </p>
                <p>
                  This material represents a valuable historical record of cutting-edge health and longevity research circulating in elite circles during the relevant time period.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
