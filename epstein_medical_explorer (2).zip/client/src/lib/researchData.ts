export interface ResearchCategory {
  id: string;
  name: string;
  description: string;
  resultCount: number;
  documents: string[];
  keyTopics: string[];
  color: string;
}

export interface ResearchFinding {
  id: string;
  category: string;
  query: string;
  source: "Jmail" | "JDrive" | "Jwiki";
  documentType: "research_paper" | "proposal" | "discussion" | "news_article" | "clinical_data";
  content: string;
  documentFiles?: string[];
  timestamp: string;
}

export const researchCategories: ResearchCategory[] = [
  {
    id: "aging_longevity",
    name: "Aging & Longevity",
    description: "Biological mechanisms of aging, life extension, and healthspan optimization",
    resultCount: 28,
    documents: ["EFTA00611136.pdf", "EFTA01693796.pdf", "EFTA01724363.pdf"],
    keyTopics: ["senescence", "telomeres", "biological age", "age reversal", "gerontology"],
    color: "from-amber-500 to-orange-500"
  },
  {
    id: "mitochondrial_health",
    name: "Mitochondrial Health",
    description: "Cellular energy production and mitochondrial dysfunction in aging",
    resultCount: 20,
    documents: ["EFTA00611136.pdf", "EFTA00799222.pdf", "EFTA00688175.pdf"],
    keyTopics: ["NAD+", "ATP", "mitochondrial transplant", "OXPHOS", "mtDNA"],
    color: "from-green-500 to-emerald-500"
  },
  {
    id: "nutrition_supplements",
    name: "Nutrition & Supplements",
    description: "Nutritional optimization and nutraceutical interventions (HIGHEST CATEGORY)",
    resultCount: 38,
    documents: ["EFTA00625612.pdf", "EFTA00833171.pdf", "EFTA01205723.pdf"],
    keyTopics: ["vitamins", "resveratrol", "CoQ10", "probiotics", "microbiome", "milk", "plants"],
    color: "from-green-600 to-teal-500"
  },
  {
    id: "cancer_oncology",
    name: "Cancer & Oncology",
    description: "Cancer prevention, treatment, and immunological approaches",
    resultCount: 24,
    documents: ["EFTA00611528.pdf", "EFTA02688139.pdf", "EFTA01140242.pdf"],
    keyTopics: ["immunotherapy", "CAR-T", "checkpoint inhibitors", "tumor biology", "prevention"],
    color: "from-red-500 to-pink-500"
  },
  {
    id: "consciousness_brain",
    name: "Consciousness & Brain Health",
    description: "Cognitive function, neurological health, and consciousness studies",
    resultCount: 28,
    documents: ["EFTA00730495.pdf", "EFTA00821685.pdf", "EFTA00821707.pdf"],
    keyTopics: ["cognitive decline", "Alzheimer", "Parkinson", "neuroplasticity", "consciousness"],
    color: "from-purple-500 to-indigo-500"
  },
  {
    id: "experimental_treatments",
    name: "Experimental Treatments",
    description: "Novel and emerging therapeutic approaches",
    resultCount: 30,
    documents: ["EFTA01620793.pdf", "EFTA00781551.pdf", "EFTA00783816.pdf"],
    keyTopics: ["stem cells", "gene therapy", "regenerative medicine", "peptides", "nasal delivery"],
    color: "from-blue-500 to-cyan-500"
  },
  {
    id: "cardiovascular_health",
    name: "Cardiovascular Health",
    description: "Heart health, vascular function, and circulation",
    resultCount: 22,
    documents: ["EFTA01210275.pdf", "EFTA00589347.pdf", "EFTA00668688.pdf"],
    keyTopics: ["atherosclerosis", "endothelial function", "blood pressure", "cholesterol"],
    color: "from-rose-500 to-red-500"
  },
  {
    id: "metabolic_health",
    name: "Metabolic Health",
    description: "Metabolic optimization and metabolic disease prevention",
    resultCount: 18,
    documents: ["EFTA01113072.pdf", "EFTA01620819.pdf", "EFTA00357096.pdf"],
    keyTopics: ["insulin resistance", "glucose metabolism", "metabolic syndrome", "obesity"],
    color: "from-yellow-500 to-amber-500"
  },
  {
    id: "inflammation_immunity",
    name: "Inflammation & Immunity",
    description: "Chronic inflammation and immune system optimization",
    resultCount: 20,
    documents: ["EFTA00508397.pdf", "EFTA00516734.pdf", "EFTA00786948.pdf"],
    keyTopics: ["inflammaging", "immune system", "autoimmune", "oxidative stress", "cytokine"],
    color: "from-orange-500 to-red-500"
  },
  {
    id: "physical_health_recovery",
    name: "Physical Health & Recovery",
    description: "Physical fitness, exercise, and recovery optimization",
    resultCount: 22,
    documents: ["EFTA01620704.pdf", "EFTA01620806.pdf", "EFTA01620869.pdf"],
    keyTopics: ["exercise", "muscle", "strength", "athletic performance", "rehabilitation"],
    color: "from-indigo-500 to-blue-500"
  }
];

export const researchFindings: ResearchFinding[] = [
  {
    id: "finding-001",
    category: "mitochondrial_health",
    query: "mitochondria",
    source: "JDrive",
    documentType: "research_paper",
    content: "Study on declining NAD+ levels inducing pseudohypoxic state disrupting nuclear-mitochondrial communication during aging",
    documentFiles: ["EFTA00611136.pdf"],
    timestamp: "2017-12-19"
  },
  {
    id: "finding-002",
    category: "nutrition_supplements",
    query: "vitamins",
    source: "Jmail",
    documentType: "discussion",
    content: "Correspondence regarding Laminine vitamins and supplementation protocols",
    timestamp: "2013-09-28"
  },
  {
    id: "finding-003",
    category: "consciousness_brain",
    query: "consciousness",
    source: "Jmail",
    documentType: "discussion",
    content: "References to The Science of Consciousness Conference and consciousness studies",
    timestamp: "2018-04-02"
  },
  {
    id: "finding-004",
    category: "experimental_treatments",
    query: "stem cells",
    source: "JDrive",
    documentType: "research_paper",
    content: "Stem cell therapy and regenerative medicine approaches for age-related diseases",
    documentFiles: ["EFTA01620793.pdf"],
    timestamp: "2017-12-11"
  },
  {
    id: "finding-005",
    category: "aging_longevity",
    query: "longevity",
    source: "JDrive",
    documentType: "research_paper",
    content: "Research on telomere biology and cellular senescence in aging",
    documentFiles: ["EFTA01693796.pdf"],
    timestamp: "2017-06-22"
  }
];

export const keyResearchers = [
  { name: "David Sinclair", affiliation: "Harvard Medical School", focus: "NAD+ and aging" },
  { name: "Deepak Chopra", affiliation: "Consciousness & Wellness", focus: "Holistic health" },
  { name: "Peter Attia", affiliation: "Longevity Research", focus: "Preventive medicine" }
];

export const documentStats = {
  totalResults: 340,
  totalQueries: 169,
  successRate: 100,
  sources: {
    Jmail: 2,
    JDrive: 67,
    Jwiki: 271
  },
  documentTypes: {
    news_article: 338,
    clinical_data: 1,
    proposal: 1
  }
};
